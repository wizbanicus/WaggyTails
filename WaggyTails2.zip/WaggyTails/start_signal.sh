#!/bin/bash
gnome-keyring-daemon -r
signal-desktop --user-data-dir=Persistent/Signal
