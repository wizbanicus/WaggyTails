#!/bin/bash
# find a random config grab the protocol, port and ip address
# Edit the /etc/ferm/ferm.conf 
# enable the vpn and force all data to use tun0
#
VPN_AUTH_FILE="/home/amnesia/Persistent/vpn"
VPN_FOLDER="/home/amnesia/Persistent/vpns"
FERM_CONF="/etc/ferm/ferm.conf"
FERM_CONF_BACKUP="/etc/ferm/ferm.conf.old"
FILE=$(ls $VPN_FOLDER | sort -R | tail -1)
PROTO=$(grep ^proto $VPN_FOLDER/$FILE | sed -s 's/proto //g')
IP=$(grep -m 1 ^remote $VPN_FOLDER/$FILE | sed -e 's/^remote //g' | sed -e 's/ .*$//')
PORT=$(grep -m 1 ^remote $VPN_FOLDER/$FILE | sed -e 's/^remote //g' | sed -e 's/.* //')
#Backup the config
cp $FERM_CONF $FERM_CONF_BACKUP

function restart_firewall {
  echo -e "about to restart the firewall"
  sleep 1
  /etc/init.d/ferm restart
  if [[ $? == 0 ]];then
    echo -e "successfully restarted the firewall";
  else
    echo -e "something went wrong restarting the firewall, putting things back"
    mv $FERM_CONF_BACKUP $FERM_CONF
    if [[ $1 == 0 ]];then
      restart_firewall 1
    else
      exit 1
    fi
  fi
}

echo -e "first of all we open up the internert to tun on VPN"
sed -ie 's/^ *jump log_reject;$/ACCEPT;/' /etc/ferm/ferm.conf
restart_firewall 0;
echo -e "PORT: $PORT .. PROTO: $PROTO .. IP: $IP"
sed -ie 's/mod owner uid-owner debian-tor/outerface tun0 mod owner uid-owner debian-tor/' /etc/ferm/ferm.conf
sed -ie  "s/# Local resources$/# Local resources\n            daddr $IP proto $PROTO dport $PORT {mod owner uid-owner root ACCEPT;}/" /etc/ferm/ferm.conf
####### Startng Firewall
restart_firewall 0;
echo -e "about to start VPN"
sleep 1
openvpn --config $VPN_FOLDER/$FILE --auth-user-pass $VPN_AUTH_FILE
if [[ $? == 0 ]];then
  echo -e "successfully connected to vpn";
else
  echo -e "something went wrong connecting to VPN - restart the computer"
  echo -e "file: $VPN_FOLDER/$FILE"
  echo -e "vpn commad:\n openvpn --config $VPN_FOLDER/$FILE -auth-user-pass $VPN_AUTH_FILE"
fi
